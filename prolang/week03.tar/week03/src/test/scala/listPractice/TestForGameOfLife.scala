package listPractice

import org.scalatest.FunSuite

import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class TestForGameOfLife extends FunSuite {
  
  test("test") {
    assert(true)
  }
  
}