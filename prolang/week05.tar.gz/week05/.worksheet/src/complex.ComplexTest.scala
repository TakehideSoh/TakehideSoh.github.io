package complex

object ComplexTest {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(51); val res$0 = 
	Complex(1,2);System.out.println("""res0: complex.Complex = """ + $show(res$0));$skip(14); val res$1 = 
	Complex(2,3);System.out.println("""res1: complex.Complex = """ + $show(res$1));$skip(34); val res$2 = 

	Complex(1,2).plus(Complex(2,3));System.out.println("""res2: complex.Complex = """ + $show(res$2))}
}

case class Complex(re: Double, im: Double) {
	def plus(that: Complex): Complex = Complex(re + that.re, im + that.im)
}
