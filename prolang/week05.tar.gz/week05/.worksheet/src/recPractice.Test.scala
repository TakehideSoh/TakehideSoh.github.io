package recPractice

import CalcStructure._

object Test {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(161); 

  def isNumber(str: String): Boolean = str match {
    case "*" | "+" => false
    case _ => true
  };System.out.println("""isNumber: (str: String)Boolean""");$skip(244); 
  
  def toString(tree: Tree): String = tree match {
  	case _: Leaf => tree.op
  	case _: Node => {
	  	if (isNumber(tree.op)) " " + tree.op + " "
  		else
  			Seq(toString(tree.left), toString(tree.right)).mkString("(",tree.op,")")
  	}
  };System.out.println("""toString: (tree: recPractice.CalcStructure.Tree)String""");$skip(18); val res$0 = 
  
	toString(ex1);System.out.println("""res0: String = """ + $show(res$0));$skip(16); val res$1 = 
  toString(ex2);System.out.println("""res1: String = """ + $show(res$1));$skip(16); val res$2 = 
  toString(ex3);System.out.println("""res2: String = """ + $show(res$2));$skip(278); 

	def calc(tree: Tree): Int = tree match {
		case _: Leaf => tree.op.toInt
		case _: Node => {
	  	if (isNumber(tree.op)) tree.op.toInt
  		else tree.op match {
  			case "*" => calc(tree.left) * calc(tree.right)
  			case "+" => calc(tree.left) + calc(tree.right)
  		}
		}
	};System.out.println("""calc: (tree: recPractice.CalcStructure.Tree)Int""");$skip(12); val res$3 = 

	calc(ex1);System.out.println("""res3: Int = """ + $show(res$3));$skip(11); val res$4 = 
	calc(ex2);System.out.println("""res4: Int = """ + $show(res$4));$skip(11); val res$5 = 
	calc(ex3);System.out.println("""res5: Int = """ + $show(res$5))}

  
}
