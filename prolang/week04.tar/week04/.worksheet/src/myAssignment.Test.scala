package myAssignment

import GameOfLife._

object Test {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(100); 
  println("Welcome to the Scala worksheet");$skip(18); val res$0 = 

	GameOfLife.test;System.out.println("""res0: <error> = """ + $show(res$0));$skip(4); val res$1 = 

	a;System.out.println("""res1: <error> = """ + $show(res$1))}
	
}
