object Hello {
  def main(args: Array[String]) {
    println("Hello. We come to week 4!")
  }
}
