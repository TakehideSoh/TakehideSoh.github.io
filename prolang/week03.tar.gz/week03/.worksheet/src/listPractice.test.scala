package listPractice

object test {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(79); 
  println("Welcome to the Scala worksheet");$skip(21); 

	val pair1 = (1, 3);System.out.println("""pair1  : (Int, Int) = """ + $show(pair1 ));$skip(20); 
	val pair2 = (2, 5);System.out.println("""pair2  : (Int, Int) = """ + $show(pair2 ));$skip(130); val res$0 = 

	pair2 match {
		case (1, _) => "First element is one."
		case (_, 4) => "Second element is four."
		case (_, _) => "Others."
	};System.out.println("""res0: String = """ + $show(res$0))}

}
