package work

import GameOfLife._

object Test {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(92); 
  println("Welcome to the Scala worksheet");$skip(24); 


	val a = Seq(1, 0, 0);System.out.println("""a  : Seq[Int] = """ + $show(a ));$skip(22); 
	val b = Seq(0, 0, 0);System.out.println("""b  : Seq[Int] = """ + $show(b ));$skip(22); 
	val c = Seq(1, 1, 1);System.out.println("""c  : Seq[Int] = """ + $show(c ));$skip(27); 
	val matrix = Seq(a, b, c);System.out.println("""matrix  : Seq[Seq[Int]] = """ + $show(matrix ));$skip(16); val res$0 = 
	
	show(matrix);System.out.println("""res0: <error> = """ + $show(res$0))}
}
