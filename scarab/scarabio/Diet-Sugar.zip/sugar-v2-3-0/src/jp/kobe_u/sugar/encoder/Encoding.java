package jp.kobe_u.sugar.encoder;

public enum Encoding {
    ORDER,
    XXX_DIRECT, // Unimplemented
    XXX_DIREDT_ORDER, // Unimplemented
    LOG,
    XXX_LOG_ORDER, // Unimplemented
}
