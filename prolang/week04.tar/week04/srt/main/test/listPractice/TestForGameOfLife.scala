package listPractice

import org.scalatest.FunSuite
import org.junit.runner.RunWith	
import org.scalatest.junit.JUnitRunner
import GameOfLife._
import annotation.tailrec

@RunWith(classOf[JUnitRunner])
class TestForGameOfLife extends FunSuite {
  @tailrec
  final def transNtimes(n: Int, matrix: Seq[Seq[Int]]): Seq[Seq[Int]] = n match {
    case 0 => matrix
    case _ => transNtimes(n - 1, trans(matrix))
  }

  val mat_size_3 = Seq(Seq(0, 0, 0), Seq(1, 1, 1), Seq(0, 0, 0))
  val mat_size_5: Seq[Seq[Int]] = (1 to 5).map { _ => (1 to 5).map { i => if (i % 2 == 0) 0 else 1 } }

  test("(TES-1) test example 1") {
    assert(true)
  }
  
  test("(TES-2) test example 2") {
    assert(inc(3) == 4)
  }    
  
  test("(GNS-1) (matrix size 3) getNeighborsState") {
    assert(getNeighborsState(1, 1, mat_size_3).count(_ == 1) === 2)
  }

  test("(GNS-2) (matrix size 3) getNeighborsState Test2") {
    assert(getNeighborsState(0, 1, mat_size_3).count(_ == 1) === 3)
  }

  test("(GNS-3) (matrix size 3) getNeighborsState 3") {
    assert(getNeighborsState(2, 1, mat_size_3).count(_ == 1) === 3)
  }

  test("(GNS-4) (matrix size 5) getNeighborsState 4") {
    assert(getNeighborsState(0, 4, mat_size_5).count(_ == 1) === 1)
  }

  test("(GNS-5) (matrix size 5) getNeighborsState 5") {
    assert(getNeighborsState(4, 4, mat_size_5).count(_ == 1) === 1)
  }

  test("(GNS-6) (matrix size 5) getNeighborsState 6") {
    assert(getNeighborsState(4, 3, mat_size_5).count(_ == 1) === 4)
  }

  test("(GNC-1) (current is live) getNextCellState 1") {
    assert(getNextCellState(1, Seq(0, 0, 0, 0, 0, 0, 1, 1)) === 1)
  }

  test("(GNC-2) (current is live) getNextCellState 2") {
    assert(getNextCellState(1, Seq(1, 1, 0, 1, 0, 0, 0, 0)) === 1)
  }

  test("(GNC-3) (current is live) getNextCellState 3") {
    assert(getNextCellState(1, Seq(1, 1, 0, 1, 0, 1, 0, 0)) === 0)
  }

  test("(GNC-4) (current is live) getNextCellState 4") {
    assert(getNextCellState(1, Seq(1, 0, 0, 0, 0, 0, 0, 0)) === 0)
  }

  test("(GNC-5) (current is dead) getNextCellState 5") {
    assert(getNextCellState(0, Seq(1, 0, 0, 1, 0, 0, 1, 0)) === 1)
  }

  test("(GNC-6) (current is dead) getNextCellState 6") {
    assert(getNextCellState(0, Seq(1, 0, 0, 1, 0, 1, 1, 1)) === 0)
  }

  test("(GNC-7) (current is dead) getNextCellState 7") {
    assert(getNextCellState(0, Seq(0, 0, 0, 0, 0, 0, 0, 0)) === 0)
  }

  test("(TRN-1) (matrix size 3) trans 1") {
    val mat = transNtimes(1, mat_size_3)
    val dim = mat.size
    assert((0 to dim - 1).forall(x =>
      (0 to dim - 1).forall(y =>
        if (y == 1) mat(x)(y) == 1 else mat(x)(y) == 0)))
  }

  test("(TRN-2) (matrix size 3) trans 2") {
    val mat = transNtimes(2, mat_size_3)
    val dim = mat.size
    assert((0 to dim - 1).forall(x =>
      (0 to dim - 1).forall(y =>
        if (x == 1) mat(x)(y) == 1 else mat(x)(y) == 0)))
  }

  test("(TRN-3) (matrix size 5) trans 3") {
    val mat = transNtimes(2, mat_size_5)
    val dim = mat.size
    assert((0 to dim - 1).forall(x =>
      (0 to dim - 1).forall(y => (x, y) match {
        case (2, 0) | (2, 2) | (2, 4) => mat(x)(y) == 1
        case (_, _) => mat(x)(y) == 0
      })))
  }

  test("(TRN-4) (matrix size 5) trans test4") {
    val mat = transNtimes(3, mat_size_5)
    val dim = mat.size
    assert((0 to dim - 1).forall(x =>
      (0 to dim - 1).forall(y => (x, y) match {
        case (_, _) => mat(x)(y) == 0
      })))
  }

  //  test("show function") {
  //    var result = true
  //    try {
  //    	show(matrix1)
  //    } catch {
  //      case e: java.lang.Exception => result = false
  //    }
  //    assert(result)
  //  }  
  
  // val mat_size_10: Seq[Seq[Int]] = (1 to 10).map { _ => (1 to 10).map { i => if (i % 2 == 0) 0 else 1 } }
  //  test("(matrix size 10) trans 3") {
  //    val mat = transNtimes(6, mat_size_10)
  //    val dim = mat.size
  //    assert((0 to dim - 1).forall(x =>
  //      (0 to dim - 1).forall(y => (x, y) match {
  //        case (3, 9) | (6, 9) => mat(x)(y) == 1        
  //        case (_, _) => mat(x)(y) == 0
  //      })))
  //  }
  //  
  //  test("(matrix size 10) trans 4") {
  //    val mat = transNtimes(7, mat_size_10)
  //    val dim = mat.size
  //    assert((0 to dim - 1).forall(x => 
  //      (0 to dim - 1).forall(y => (x, y) match {
  //        case (_, _) => mat(x)(y) == 0
  //      })))
  //  }  

}