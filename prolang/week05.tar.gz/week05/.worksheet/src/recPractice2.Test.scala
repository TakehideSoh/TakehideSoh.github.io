package recPractice2

import CalcStructure._

object Test {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(103); 
  println("Welcome to the Scala worksheet");$skip(9); val res$0 = 
  
  ex1;System.out.println("""res0: recPractice2.CalcStructure.Node = """ + $show(res$0));$skip(5); val res$1 = 
	ex2;System.out.println("""res1: recPractice2.CalcStructure.Node = """ + $show(res$1));$skip(5); val res$2 = 
	ex3;System.out.println("""res2: recPractice2.CalcStructure.Node = """ + $show(res$2))}
}
