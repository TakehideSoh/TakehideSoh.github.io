package listPractice

object Listlecture1 {
  def sum(xs: List[Int]): Int = {
    if (xs.isEmpty) 0 
    else xs.head + sum(xs.tail)
  }

  def max(xs: List[Int]): Int = ???
  
  
}