package listPractice

import org.scalatest.FunSuite

import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class ListsSuite extends FunSuite {
  test("one plus one is two")(assert(1 + 1 == 2))

  import Listlecture1._
  test("sum of 3, 4, and 5") {
    assert(sum(List(3,4,5)) === 12)
  }	
}