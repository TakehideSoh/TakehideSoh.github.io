/**
 * Various restart strategies.
 */

package org.sat4j.minisat.restarts;

