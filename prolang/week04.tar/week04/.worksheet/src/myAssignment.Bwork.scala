package myAssignment
	
object Bwork {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(82); 

  println("Welcome to the Scala worksheet");$skip(50); 
  
  def sayHello { println("Hello from Bwork") };System.out.println("""sayHello: => Unit""");$skip(48); 

	def main(args: Array[String]) {
		sayHello
	};System.out.println("""main: (args: Array[String])Unit""")}
  
}
