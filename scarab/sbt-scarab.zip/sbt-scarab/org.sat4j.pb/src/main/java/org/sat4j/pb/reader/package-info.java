/**
 * Readers for opb instances.
 */

package org.sat4j.pb.reader;

