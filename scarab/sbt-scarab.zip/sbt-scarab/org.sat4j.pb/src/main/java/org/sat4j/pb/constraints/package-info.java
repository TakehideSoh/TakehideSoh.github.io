/**
 * Implementation of data structures for pseudo boolean constraints.
 */

package org.sat4j.pb.constraints;

