package listPractice

import org.scalatest.FunSuite

import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class ListsSuite01 extends FunSuite {
  
  import ListMethods._
  
  test("trebleHead") {
    assert(trebleHead(List(4,3,5)) === 12)
  }
  test("trebleLength") {
    assert(trebleLength(List(3,4,5)) === 9)
  }
  test("bothEndsOfList") {
    assert(bothEndsOfList(List(3,4,5))===List(3,5))
  }
  test("sum range") {
    assert(sumRange(3,5) === 12)    
    assert(sumRange(300,799) === 274750)
  }	
  test("sum range average") {
    assert(sumRangeAverage(3,5) === 4)        
  }
  test("permutation") {
    assert(permutation(30,4) === 657720)
  }
  test("rotateRight") {
    assert(rotateRight[String](List("abc","bb","CCCC"))===List("CCCC", "abc", "bb"))
  }
  test("palindrome") {
    assert(palindrome[String](List("A","B","B","A"))===true)
  }
  
}