package myAssignment

import Bwork._

object Awork {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(96); 
  println("Welcome to the Scala worksheet");$skip(47); 

	def sayHello { println("Hello from Awork") };System.out.println("""sayHello: => Unit""");$skip(12); 
	
	sayHello;$skip(16); 
	Awork.sayHello;$skip(16); 
	Bwork.sayHello}
}
