package listPractice 

package object common {
  type ??? = Nothing
  type *** = Any
}