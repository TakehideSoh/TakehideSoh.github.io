package classPractice

object RelationalTest {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(79); 
  // ここにテストを記述
  println("test")}
}

case class RelationalNum(numer: Int, denom: Int) {
	def plus(that: RelationalNum) = ???
	def minus(that: RelationalNum) = ???
	def times(that: RelationalNum) = ???
	def divide(that: RelationalNum) = ???
}
