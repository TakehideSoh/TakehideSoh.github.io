package listPractice

import GameOfLife._

object week03 {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(89); 
  println("welcome to week03")}

}
