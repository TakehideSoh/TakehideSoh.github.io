/**
 * Various heuristics for the next variable to branch on.
 */

package org.sat4j.pb.orders;

